# Hardseal Edge — Delivery Note

**Bundle name:** Hardseal Edge — Trophy Case T1, Jetson Orin Nano Super sustained-deployment evidence (run identifier `overnight_full_matrix_20260426T012800Z`, session `T1_thermal_saturation_yolov8n_int8_25W_1M_iter`)

**Customer:** Engagement evaluation copy — the Trophy Case bundle. This is the artifact Hardseal Edge sends as second-touch after a verified-channel first-touch lands. Customer name is filled in by the operator at engagement time before forwarding to a named recipient.

**Delivery date (UTC):** 2026-04-26T11:08:40Z (packet creation timestamp; bundle is reusable indefinitely against the same chain root).

**Delivery owner:** rico@hardseal.ai

**Engagement reference:** Trophy Case demo asset — not tied to a specific SOW. Operator overwrites this line with the engagement folder path or invoice reference once the bundle is forwarded to a named prospect.

---

## What this delivery contains

The accompanying bundle is a Hardseal Edge evidence delivery — a cryptographically signed JSON evidence packet recording one AI-inference session on the device named in this note, plus the materials necessary for the recipient to verify the packet independently.

Operator checklist (what's present in this bundle):

- [x] `packet.json` — signed evidence packet for the T1 thermal-saturation session.
- [x] `packet.md` — human-readable view of the same evidence.
- [x] `verify_standalone.py` — single-file vendored verifier (stdlib-only Python, no install required).
- [x] `../QUICKSTART.md` — verifier walkthrough and 8-check explanation (one directory up; included in zipped distribution).
- [x] `../README.md` — example folder index, sourced from the same canonical location.
- [x] This `EDGE_DELIVERY_NOTE.md`.
- [ ] _CHAIN_ROOT_MANIFEST.md is not required for a single-packet delivery; manifest is added when the delivery is multi-packet (e.g., the 22-packet full-matrix bundle)._

---

## How to verify the packet

From the unzipped bundle directory, on any machine with Python 3.8 or later:

```
python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json
```

The verifier runs the same 8-check sequence Hardseal Edge runs internally; full check-by-check explanation lives in `QUICKSTART.md`.

Expected output for a clean packet: 8 PASS lines and `result: PASS`. Exit code `0`.

The verifier:

- Uses the Python standard library only — no `pip install`, no virtual environment.
- Makes no network calls.
- Depends on no Hardseal-hosted service.
- Will produce the same answer in 5 years against the same packet.

For verification issues or environment troubleshooting, see Support below.

---

## What PASS means

A `result: PASS` from the verifier confirms that:

- All required header and section fields are present and well-formed.
- The packet's recorded `schema_version` (`1.0`) and `operational_class` (`edge-inference-verification`) are recognized by the verifier.
- The cryptographic anchor (engine SHA-256 `c74674450a88c7ea0a774d156bd0481c2f2f0e7ebb4993e9e807853135f3e140`) is present in the model section.
- The SHA-256 hash chain over the packet's contents recomputes to the stored chain root `4bb3343b336307a10ea0934128d6f46f098ddcd693493047c893b00ebd6cb7a1` — i.e., **no field of the packet has been modified since signing**.
- The packet contains no language asserting claims Hardseal Edge is doctrinally not permitted to make.

In plain terms: PASS confirms the named Jetson Orin Nano Super device executed the named TensorRT engine (yolov8n INT8, runtime version 10.3.0) under the named configuration (25 W power mode, pinned clocks, JetPack 6.2.1 / L4T R36.4.7), produced the recorded measurements across 1,000,000 iterations of sustained inference (~57 minutes wall, mean 3.405 ms, p50 3.404 ms, p99 3.431 ms, throughput 293.07 FPS, thermal rise from ~51 °C to ~56 °C), and the entire record is sealed against tampering.

---

## What PASS does NOT mean

A `result: PASS` from the verifier does **not** confirm any of the following. These determinations are out of scope of a Hardseal Edge packet and require separate qualified judgment:

- The recipient's organization is compliant with CMMC, NIST 800-171, FedRAMP, DO-178, ISO 27001, SOC 2, or any other regulatory or contractual standard.
- Any specific compliance control is satisfied by the recorded evidence on its own.
- An assessor, registered provider organization, C3PAO, government agency, prime contractor, or regulator has approved, certified, endorsed, or authorized the recorded evidence or the system that produced it.
- The underlying AI model (yolov8n INT8) is safe, accurate, fit for any operational purpose, or approved for any specific use case.
- The deployment environment surrounding the recorded session is secure as a whole.
- The recorded measurements generalize to other devices, other thermal envelopes, other input distributions, other model precisions, or other workload types without separate measurement.

The cryptographic claim is narrow on purpose. The narrowness is what makes the evidence verifiable.

---

## Relevance disclaimer (verbatim — required language)

The following disclaimer language is part of every Hardseal Edge delivery and is reproduced verbatim from the Hardseal Edge collector specification:

> This evidence is relevant to the listed control families but does not, on its own, satisfy any specific control. Hardseal Edge attests only to the cryptographic integrity of the recorded session. Assessment of control satisfaction requires the customer's qualified assessor.

Control families this delivery may be relevant to:

- No specific control families — this packet is methodology-demonstration evidence (sustained-deployment thermal-saturation behavior of an AI-inference workload on Jetson Orin Nano Super hardware). The Trophy Case asset is intended to demonstrate the *type* of evidence Hardseal Edge produces. A customer-specific engagement maps Hardseal Edge packets to candidate control families during scoping; the operator overwrites this line with that mapping at engagement time.

The list above states *which control families this evidence may be relevant to*. It does **not** state that any control on the list is satisfied by this evidence alone. Mapping inference telemetry to control satisfaction is the sole responsibility of the customer's qualified assessor.

---

## Packet metadata reference

For the recipient's records and verification cross-check:

- **Operational class:** edge-inference-verification
- **Schema version:** 1.0
- **Hash-chain algorithm:** sha256_chain_v1
- **Verification command:** `python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json`
- **Expected exit codes:** `0` = PASS, `1` = FAIL, `2` = usage / unreadable file

| Packet (filename) | Chain root (first 32 hex) | Verifier result on delivery date |
|---|---|---|
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` | `4bb3343b336307a10ea0934128d6f46f098ddcd6...` | PASS |

Full chain root (for a recipient who wants to record it byte-for-byte): `4bb3343b336307a10ea0934128d6f46f098ddcd693493047c893b00ebd6cb7a1`

---

## Methodology summary (one-glance)

| Field | Value |
|---|---|
| Device | Jetson Orin Nano Super (NVIDIA) |
| OS / kernel | Ubuntu / L4T R36.4.7 |
| JetPack | 6.2.1 |
| Power mode | 25 W (pinned clocks) |
| Engine | `yolov8n_int8.engine` (TensorRT 10.3.0, INT8 precision, 640×640 input) |
| Engine SHA-256 | `c74674450a88c7ea0a774d156bd0481c2f2f0e7ebb4993e9e807853135f3e140` |
| Iterations | 1,000,000 (50,000 per block × 20 blocks) |
| Warm-up iterations | 50 |
| Wall time | 3412.14 s (~56 min 52 s) |
| Mean latency | 3.405 ms |
| Median (p50) | 3.404 ms |
| p95 latency | 3.422 ms |
| p99 latency | 3.431 ms |
| Max latency | 10.39 ms (1 outlier in histogram bucket 10.0–10.5 ms) |
| Throughput | 293.07 FPS |
| Thermal pre-soak | ~51 °C (CPU/GPU thermal zones at start) |
| Thermal post-soak | ~56 °C (largest delta +5.0 °C, cluster-mean delta ~+3.2 °C) |
| Input data | Synthetic (np.random) — explicit packet limitation, no real sensor input |
| Sensors connected | None (camera, IMU, GPS, barometer all `not_connected` per packet) |
| Offline mode | true (no network calls during inference) |

The point of the T1 session: demonstrate that the device sustains a stable inference latency distribution across one million consecutive iterations under a closed thermal loop, and that Hardseal Edge can seal the entire record into a single cryptographically verifiable packet.

---

## Support

Questions about interpreting these artifacts, verification environment troubleshooting, or integrating Hardseal Edge evidence into the recipient's compliance evidence package:

- **Email:** rico@hardseal.ai
- **Response window:** 4 business hours during the engagement window; 1 business day post-acceptance.
- **Out-of-scope questions** (legal interpretation, regulatory determination, assessment opinion) are explicitly NOT supported by Hardseal — those route to the recipient's qualified assessor or counsel.

---

## Internal delivery checklist (operator-only — strip before sending to a named recipient)

Before sealing the bundle and sending it, confirm:

- [x] The T1 packet verifies PASS via `python3 verify_standalone.py` (run on canonical CI and locally on Jetson 2026-04-26).
- [x] This `EDGE_DELIVERY_NOTE.md` is instantiated from the template at `docs/edge/templates/EDGE_DELIVERY_NOTE.md` and every fill-in placeholder is replaced with concrete content.
- [ ] **Customer name field** is filled in for the named recipient (currently set to "Engagement evaluation copy" — operator overwrites at send time).
- [ ] **Engagement reference** field is filled in with the engagement folder path or invoice reference (currently set to "Trophy Case demo asset").
- [x] Packet metadata table is filled in (chain root, verifier result, methodology summary).
- [x] The relevance disclaimer is present verbatim — not paraphrased, not edited, not abbreviated.
- [x] The "What PASS does NOT mean" section is intact — not edited to soften, not removed.
- [x] The bundle's `packet.json`, `packet.md`, `verify_standalone.py`, `QUICKSTART.md`, and `README.md` are present and the operator checklist above reflects what's actually in the bundle.
- [x] No language anywhere in this delivery asserts compliance satisfaction, certification, endorsement, authorization, assessor judgment, or guarantee of fitness — for any standard, by any party. (Banned-phrase scan: clean.)
- [x] Pre-commit guardrail's banned-phrase scan PASSes on this note's content.
- [ ] **This internal-checklist section** is removed or struck through from the recipient-facing copy. The recipient never sees this checklist. (Operator strikes this section before forwarding.)

---

**Filed: 2026-04-26 PM ET. Hardseal Edge.**

*This note is the canonical Trophy Case delivery note. It accompanies the T1 thermal-saturation packet whenever the Trophy Case bundle is forwarded as a second-touch asset. Updates to this note require a `docs(edge)` commit and re-verification of the metadata table against the live packet.*
