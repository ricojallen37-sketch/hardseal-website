# Hardseal Edge Evidence Report

**Session ID:** `T1_thermal_saturation_yolov8n_int8_25W_1M_iter`
**Created (UTC):** 2026-04-26T11:08:40Z
**Operational class:** edge-inference-verification
**Schema version:** 1.0
**Offline mode:** true
**Doctrine:** `hardseal_edge/DOCTRINE.md`

## Device

| field | value |
|---|---|
| hostname | rico-desktop |
| platform | jetson_orin_nano_super |
| OS | ubuntu  |
| kernel |  |
| L4T | R36.4.7 |
| JetPack | 6.2.1 |
| power mode | 25W |
| clocks pinned | True |

## Model

| field | value |
|---|---|
| name | yolov8n_int8 |
| runtime | tensorrt 10.3.0 |
| precision | int8 |
| input shape | [1, 3, 640, 640] |
| engine path | `yolov8n_int8.engine` |
| engine SHA-256 | `c74674450a88c7ea0a774d156bd0481c2f2f0e7ebb4993e9e807853135f3e140` |
| vendor metadata header | 1812 bytes (recorded separately; not included in engine SHA-256 if hashed over engine bytes alone) |

## Benchmark

| field | value |
|---|---|
| warmup iterations | 50 |
| recorded iterations | 1000000 |
| wall seconds | 3412.14 |
| mean (ms) | 3.405 |
| stdev (ms) | 0.015 |
| min (ms) | 3.372 |
| p50 (ms) | 3.404 |
| p95 (ms) | 3.422 |
| p99 (ms) | 3.431 |
| max (ms) | 10.390 |
| throughput (FPS) | 293.07 |
| pre-thermal | 51.91°C, 51.78°C, —, —, —, 51.19°C, 50.84°C, 51.22°C |
| post-thermal | 55.97°C, 56.91°C, —, —, —, 55.56°C, 54.97°C, 55.44°C |

### Histogram

| range (ms) | count |
|---|---|
| [0.0, 4.0) | 999935 |
| [4.0, 4.5) | 27 |
| [4.5, 5.0) | 36 |
| [5.0, 6.0) | 0 |
| [6.0, 7.0) | 1 |
| [7.0, 8.0) | 0 |
| [8.0, 9.0) | 0 |
| [9.0, 9.5) | 0 |
| [9.5, 10.0) | 0 |
| [10.0, 10.5) | 1 |
| [10.5, 12.0) | 0 |
| [12.0, 15.0) | 0 |
| [15.0, 20.0) | 0 |
| [20.0, 50.0) | 0 |

### Block-split

| block | iterations | mean (ms) | p50 | p99 | min | max |
|---|---|---|---|---|---|---|
| 0 | 0–50000 | 3.412 | 3.419 | 3.438 | 3.372 | 4.999 |
| 1 | 50000–100000 | 3.397 | 3.392 | 3.432 | 3.372 | 4.666 |
| 2 | 100000–150000 | 3.409 | 3.412 | 3.436 | 3.374 | 4.978 |
| 3 | 150000–200000 | 3.405 | 3.405 | 3.427 | 3.388 | 4.670 |
| 4 | 200000–250000 | 3.406 | 3.405 | 3.430 | 3.388 | 10.390 |
| 5 | 250000–300000 | 3.404 | 3.403 | 3.425 | 3.387 | 4.601 |
| 6 | 300000–350000 | 3.404 | 3.403 | 3.425 | 3.388 | 4.647 |
| 7 | 350000–400000 | 3.404 | 3.403 | 3.425 | 3.387 | 4.647 |
| 8 | 400000–450000 | 3.404 | 3.403 | 3.428 | 3.387 | 4.649 |
| 9 | 450000–500000 | 3.404 | 3.403 | 3.424 | 3.387 | 4.644 |
| 10 | 500000–550000 | 3.404 | 3.403 | 3.427 | 3.386 | 4.472 |
| 11 | 550000–600000 | 3.403 | 3.403 | 3.423 | 3.387 | 4.577 |
| 12 | 600000–650000 | 3.405 | 3.404 | 3.426 | 3.386 | 4.561 |
| 13 | 650000–700000 | 3.405 | 3.404 | 3.427 | 3.388 | 4.655 |
| 14 | 700000–750000 | 3.404 | 3.404 | 3.426 | 3.385 | 4.572 |
| 15 | 750000–800000 | 3.404 | 3.403 | 3.425 | 3.386 | 4.568 |
| 16 | 800000–850000 | 3.405 | 3.404 | 3.425 | 3.388 | 4.555 |
| 17 | 850000–900000 | 3.407 | 3.406 | 3.427 | 3.390 | 4.645 |
| 18 | 900000–950000 | 3.408 | 3.407 | 3.433 | 3.389 | 4.573 |
| 19 | 950000–1000000 | 3.405 | 3.405 | 3.425 | 3.387 | 4.664 |

## Sensors

| sensor | state |
|---|---|
| barometer | not_connected |
| camera | not_connected |
| gps | not_connected |
| imu | not_connected |

## Limitations

- synthetic input data (np.random) was used; no real sensor input
- single device tested; cross-device variance unmeasured
- no flight controller or autonomy integration; bench evidence only
- 1,000,000-iteration thermal saturation soak (~58 min wall) — sustained-deployment evidence

## Integrity

| field | value |
|---|---|
| algorithm | `sha256_chain_v1` |
| chain root | `4bb3343b336307a10ea0934128d6f46f098ddcd693493047c893b00ebd6cb7a1` |
| tamper status | clean |
| verify command | `python3 -m hardseal_edge.verify <packet.json>` |

**Cryptographic claim:**

> Hardseal Edge cryptographically attests that the named device executed the named model under the named configuration and produced the recorded measurements, and that no field of this packet has been modified since signing.

## What This Report Does Not Claim

> This report does not certify compliance with any standard, validate safety properties of any system, approve autonomy or mission behavior, replace formal assessment, replace independent verification, or attest to fitness for any operational purpose. Hardseal Edge attests only to the cryptographic integrity of the recorded session — that what is named in this packet is what executed and what was measured.
