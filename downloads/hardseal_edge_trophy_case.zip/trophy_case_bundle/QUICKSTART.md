# Hardseal Edge — Quickstart

**Hardseal Edge lets you verify what actually happened.**

Most edge AI vendors ship benchmarks. Hardseal Edge ships **tamper-evident evidence** — cryptographically signed JSON packets that bind device identity, model identity, runtime configuration, measured behavior, and sensor presence into an SHA-256 hash chain that any third party can verify in 30 seconds with stdlib Python and no Hardseal infrastructure.

## System architecture at a glance

![Hardseal Edge architecture](./architecture.svg)

The diagram shows the full data flow: Jetson measurement → packet construction with engine SHA-256 anchor → SHA-256 hash chain → signed packet → independent verification (any reader, any time) and/or collector ingestion into a Hardseal readiness pack. The dashed boundary is the FCA-exposure firewall: packets attest narrowly to inference integrity; they do not certify or satisfy any compliance control.

The cryptographic claim is narrow on purpose: *what is named in this packet is what executed and what was measured.* Everything else — accuracy, compliance, autonomy, mission readiness — is out of scope and disclaimed in every packet.

---

## Run the example

From this folder:

```
cd examples
python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json
```

Expected output:

```
  PASS: header fields complete
  PASS: schema_version supported
  PASS: operational_class recognized
  PASS: required sections present
  PASS: engine SHA-256 present
  PASS: offline mode declared
  PASS: hash chain valid
  PASS: no banned legal language detected

result: PASS
```

Exit code 0.

That sample packet records 1,000,000 sustained inference operations (yolov8n INT8 at 25 W) on an NVIDIA Jetson Orin Nano Super. The chip held mean latency 3.405 ms and stdev 0.0152 ms across 56 minutes 52 seconds, with junction temperature rising only 3 to 5 degrees Celsius.

---

## What the verifier checks

Each verification run executes 8 named checks:

1. **Header fields complete.** All required header keys present (`packet_type`, `schema_version`, `operational_class`, `session_id`, `created_utc`, `offline_mode`, `doctrine_url`).
2. **Schema version supported.** Verifier was built to recognize this packet's schema (v1.0).
3. **Operational class recognized.** Verifier was built to recognize this packet's operational class (`edge-inference-verification`).
4. **Required sections present.** Five evidence sections: device, model, benchmark, sensors, limitations.
5. **Engine SHA-256 present.** Model section carries a 64-character hex digest of the engine bytes — the cryptographic anchor for the model claim.
6. **Offline mode declared.** Boolean flag declaring whether the measurement was taken with network connectivity.
7. **Hash chain valid.** Recompute the SHA-256 hash chain over packet header + ordered sections; compare to the stored chain root. Mismatch identifies the first mutated section by name.
8. **No banned legal language detected.** Packet is scanned for over-claim phrases that Hardseal Edge is doctrinally not permitted to assert.

A `result: PASS` means the packet has not been modified, the cryptographic anchor is intact, and the evidence does not over-claim what Hardseal Edge is permitted to attest to.

---

## What a packet attests to

Each Hardseal Edge evidence packet attests — and only attests — to three things about its recorded session:

1. The named device executed the named engine under the named configuration. The engine SHA-256 binds the model claim to the actual bytes that ran.
2. The named device produced the recorded measurements (mean / p50 / p95 / p99 / stdev / max / min / throughput / thermal pre/post).
3. No field of the packet has been modified since signing. Recomputing the chain from packet contents produces the stored root if and only if every byte in every section is unchanged.

## What a packet does NOT claim

- It does not certify CMMC compliance, FedRAMP authorization, DO-178 airworthiness, or any other formal standard.
- It does not validate detection accuracy of the model.
- It does not approve autonomy or mission behavior.
- It does not replace formal assessment by a qualified third party.
- It does not generalize to other devices, other thermal envelopes, other input distributions, or other model precisions without measurement.
- It does not assert any safety property of the system the engine is part of.

The narrowness is the moat. Every claim Hardseal Edge does make, it can defend.

---

## How to demonstrate the failure mode

The verifier's behavior under tampering is the strongest evidence the success case was real:

1. Open the sample `packet.json` in a text editor.
2. Change any single value — for example, change the `mean_ms` from `3.4050` to `3.4051`.
3. Save the file.
4. Re-run the verifier.
5. Watch it identify the first mutated section by name and return `result: FAIL`.
6. Restore the original value to see PASS again.

This is the demonstration that the cryptographic anchor is real, not assumed.

---

## Trust posture

The trust surface of `verify_standalone.py` is the file itself — about 250 lines of stdlib-only Python. Read it before running it.

A reviewer with stronger trust requirements should re-implement the verifier from scratch in any language. The chain construction is fully specified by the `compute_seed`, `compute_section_hashes`, and `compute_chain_root` functions in `verify_standalone.py`. Any compliant reimplementation should produce byte-identical chain roots from the same packet inputs.

The verifier:

- Uses Python standard library only (`hashlib`, `json`, `dataclasses`).
- Makes no network calls.
- Depends on no Hardseal-hosted service.
- Returns deterministic exit codes (`0` = PASS, `1` = FAIL, `2` = usage / unreadable).
- Will work in 5 years against the same packets even if Hardseal has evolved.

---

## What's in this folder

| Path | Purpose |
|---|---|
| `QUICKSTART.md` | This file. |
| `examples/verify_standalone.py` | Single-file standalone verifier. |
| `examples/T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` | Sample evidence packet. |
| `examples/T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.md` | Human-readable view of the same packet. |
| `examples/README.md` | Step-by-step run instructions and tampering demo. |

The canonical Hardseal Edge module lives at `hardseal_edge/` in the Hardseal repo. The standalone verifier in this folder is a vendored copy intended for distribution outside the repo (customers, auditors, acquirers).

---

## Common reviewer questions

**"How do I know the verifier itself isn't lying?"**

Read `verify_standalone.py`. Stdlib-only Python; ~250 lines. Re-implement it in another language; the spec is in the file. Hardseal's design intent is that you should not have to trust the verifier to trust the result.

**"What if I want to verify a different packet?"**

Pass any Hardseal Edge `packet.json` to `verify_standalone.py`. The verifier checks the same 8 things on every packet.

**"Can I run this offline?"**

Yes. The verifier has zero network dependency. Air-gapped customer sites, due-diligence laptops, regulator review terminals — same command, same answer.

**"What is `operational_class`?"**

A label that bounds what a packet is permitted to claim. v1.0 supports `edge-inference-verification`. Future operational classes will compose with the same hash-chain primitive but extend the section schema. The `DOCTRINE.md` in the Hardseal repo defines what each class is permitted to claim.

**"What is the `doctrine_url` field?"**

A path to the doctrine document for the packet's operational class. Tells the reader where the explicit boundary between claim and disclaimer is documented.

---

## Next steps

- Generate your own packet from your own measurement run: see `hardseal_edge/from_jetson.py` for the Jetson rep harness adapter, or `hardseal_edge/packet.py` for the lower-level builder.
- Add Hardseal Edge to a readiness review: contact rico@hardseal.ai.

---

**Hardseal Edge — Quickstart v0.1, 2026-04-26.**
