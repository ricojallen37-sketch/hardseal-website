# Hardseal Edge — Trophy Case bundle

This bundle contains **eight signed Hardseal Edge evidence packets** and the materials needed to verify each of them independently — a stdlib-only Python verifier, an out-of-band chain-root manifest, and per-packet delivery notes.

## Quick verify

From the unzipped `trophy_case_bundle/` directory, on any machine with Python 3.8 or later:

```
python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json
```

Expected output: 8 PASS lines and `result: PASS`. Exit code 0.

To verify any other packet in this bundle, replace the path with another packet directory's `packet.json` (see `CHAIN_ROOT_MANIFEST.md` for the full list of 8 packets and their chain roots).

## Bundle contents

| File / directory | What it is |
|---|---|
| `verify_standalone.py` | Single-file standalone verifier. Stdlib-only Python. No `pip install`. |
| `QUICKSTART.md` | Verifier walkthrough and 8-check explanation. |
| `EXAMPLES_README.md` | Step-by-step run instructions and tampering demo using the T1 sample packet. |
| `CHAIN_ROOT_MANIFEST.md` | Out-of-band chain-root index for all 8 packets in this bundle. |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/` | Sample packet — yolov8n INT8 at 25 W, 1,000,000-iteration thermal-saturation soak. |
| `sustained_yolov8l_int8_25W_1M_rep3/` | yolov8L INT8 at 25 W, 1,000,000-iteration sustained run (rep #3 of three). |
| `yolov8l_1M_MAXN_chain_rep[1-3]_20260428T234414Z..20260429T080047Z/` | yolov8L 1M-iter MAXN_SUPER replicate chain, 3 packets (Tuesday-night chain). |
| `yolov8l_1M_MAXN_chain_rep[1-3]_20260429T125346Z..20260429T202550Z/` | yolov8L 1M-iter MAXN_SUPER replicate chain, 3 packets (Wednesday chain). |

Each packet directory contains `packet.json` (signed evidence), `packet.md` (human-readable view), and `EDGE_DELIVERY_NOTE.md` (per-packet scope-of-assurance note).

## What this proves and does not prove

See any packet's `EDGE_DELIVERY_NOTE.md` for the full statement of scope. In short: the verifier confirms each packet has not been modified since signing and that the cryptographic anchor (engine SHA-256) is intact. It does not certify the underlying AI system as compliant with CMMC, NIST 800-171, ISO 27001, FAA airworthiness, or any other regulatory regime. It does not assess accuracy, autonomy, or mission readiness. The narrowness is the moat.

## Support

Questions or verification troubleshooting: rico@hardseal.ai

Bundle URL (always-current): https://hardseal.ai/downloads/hardseal_edge_trophy_case.zip
