# Hardseal Edge — Trophy Case bundle

This bundle contains one signed Hardseal Edge evidence packet and the materials
needed to verify it independently.

## Quick verify

From this directory, on any machine with Python 3.8 or later:

```
python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json
```

Expected output: 8 PASS lines and `result: PASS`. Exit code 0.

## Bundle contents

| File / directory | What it is |
|---|---|
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` | Signed evidence packet (JSON). |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.md` | Human-readable view of the same evidence. |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/EDGE_DELIVERY_NOTE.md` | Delivery note: what PASS does and does NOT mean, methodology summary, support contact. |
| `verify_standalone.py` | Single-file standalone verifier. Stdlib-only Python. No `pip install`. |
| `QUICKSTART.md` | Verifier walkthrough and 8-check explanation. |
| `EXAMPLES_README.md` | Index of the example-folder source canon. |
| `CHAIN_ROOT_MANIFEST.md` | Per-packet chain-root index for this bundle (single packet here, included for delivery completeness). |

## What this proves and does not prove

See `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/EDGE_DELIVERY_NOTE.md` for
the full statement of scope. In short: the verifier confirms the packet has
not been modified since signing. It does not certify anything else.

## Support

Questions or verification troubleshooting: rico@hardseal.ai
