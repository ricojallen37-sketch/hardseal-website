# Hardseal Edge — Chain Root Manifest

For the recipient's records and verification cross-check. This bundle ships eight signed evidence packets; each row below names the packet, its operational class, its full SHA-256 hash-chain root, schema version, and hash-chain algorithm. A re-run of `verify_standalone.py` against any packet must reproduce the chain root listed here byte-for-byte.

| Packet (filename) | Operational class | Chain root (full SHA-256) | Schema | Hash-chain alg |
|---|---|---|---|---|
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` | edge-inference-verification | `4bb3343b336307a10ea0934128d6f46f098ddcd693493047c893b00ebd6cb7a1` | 1.0 | sha256_chain_v1 |
| `sustained_yolov8l_int8_25W_1M_rep3/packet.json` | edge-inference-verification | `3d0aee521f267b58d6d8f40a5dae56cace52f37aa06f7d4a8740878a0c1c1782` | 1.0 | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep1_20260428T234414Z/packet.json` | edge-inference-verification | `798a580ca212648cadf2be3e147d23e37251fca7886ff3180897d2c48fe0c13b` | 1.0 | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep1_20260429T125346Z/packet.json` | edge-inference-verification | `2c0723611e2ecf028dff656045b450df514d8eb129cfbdec1c463a81512022b4` | 1.0 | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep2_20260429T035221Z/packet.json` | edge-inference-verification | `1597a26f43c1cd4615abffde095b2e3a439edece6eaafd094a39c1736c49f696` | 1.0 | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep2_20260429T163949Z/packet.json` | edge-inference-verification | `8adec610c03ece2b62844790c0a6e06535218e6cb6db54564246d9f4fc3fbd67` | 1.0 | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep3_20260429T080047Z/packet.json` | edge-inference-verification | `9ff39c3b2d5ae2f41a3db4d537c88d68f0e2d86b23bf2c29b46a7935b696e793` | 1.0 | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep3_20260429T202550Z/packet.json` | edge-inference-verification | `1d9f06a194b5bf181e40a5efc15b06959f3b1525b7762edc46a56a5d6051473e` | 1.0 | sha256_chain_v1 |

## How to verify any packet listed above

From inside the unzipped `trophy_case_bundle/` directory:

```
python3 verify_standalone.py <relative_path_to_packet.json>
```

For example:

```
python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json
```

Expected: 8 PASS lines and `result: PASS`. Exit code 0. The verifier also recomputes the chain root internally; if the recomputed value does not match the row above, the packet has been modified after signing and the verifier will return `result: FAIL`.

## Why this manifest exists

The manifest is the out-of-band comparison surface. A reviewer with the bundle and this manifest can cross-check packet integrity without trusting the verifier output alone. If a malicious party tampers with a packet AND re-signs it, the chain root in the tampered packet will not match the chain root published in this manifest — which itself can be cross-referenced against the per-packet rows on https://hardseal.ai/trophy-case.html.

The manifest is part of the cryptographic discipline: claims are bound to specific bytes, and the bytes are visible in three independent places (packet, manifest, public website).
