# Hardseal Edge — Chain Root Manifest

For the recipient's records and verification cross-check. Manifest is included
for delivery completeness even when the bundle is single-packet; multi-packet
bundles add additional rows.

| Packet (filename) | Operational class | Chain root (full SHA-256) | Schema | Hash-chain alg |
|---|---|---|---|---|
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` | edge-inference-verification | `4bb3343b336307a10ea0934128d6f46f098ddcd693493047c893b00ebd6cb7a1` | 1.0 | sha256_chain_v1 |

To verify any packet listed above:

```
python3 verify_standalone.py <relative_path_to_packet.json>
```

Expected: 8 PASS lines and `result: PASS`. Exit 0.
| `sustained_yolov8l_int8_25W_1M_rep3/packet.json` | UNKNOWN | `3d0aee521f267b58d6d8f40a5dae56cace52f37aa06f7d4a8740878a0c1c1782` | UNKNOWN | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep1_20260428T234414Z/packet.json` | UNKNOWN | `798a580ca212648cadf2be3e147d23e37251fca7886ff3180897d2c48fe0c13b` | UNKNOWN | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep2_20260429T035221Z/packet.json` | UNKNOWN | `1597a26f43c1cd4615abffde095b2e3a439edece6eaafd094a39c1736c49f696` | UNKNOWN | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep3_20260429T080047Z/packet.json` | UNKNOWN | `9ff39c3b2d5ae2f41a3db4d537c88d68f0e2d86b23bf2c29b46a7935b696e793` | UNKNOWN | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep1_20260429T125346Z/packet.json` | UNKNOWN | `2c0723611e2ecf028dff656045b450df514d8eb129cfbdec1c463a81512022b4` | UNKNOWN | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep2_20260429T163949Z/packet.json` | UNKNOWN | `8adec610c03ece2b62844790c0a6e06535218e6cb6db54564246d9f4fc3fbd67` | UNKNOWN | sha256_chain_v1 |
| `yolov8l_1M_MAXN_chain_rep3_20260429T202550Z/packet.json` | UNKNOWN | `1d9f06a194b5bf181e40a5efc15b06959f3b1525b7762edc46a56a5d6051473e` | UNKNOWN | sha256_chain_v1 |
