# Hardseal Edge — Delivery Note

**Bundle name:** Hardseal Edge — session `yolov8x_1M_MAXN_chain_rep3_20260501T030344Z` (operational class `edge-inference-verification`).

**Customer:** Engagement evaluation copy. Customer name is filled in by the operator at engagement time before forwarding to a named recipient.

**Delivery date (UTC):** 2026-05-01T12:43:29Z (packet creation timestamp; bundle is reusable indefinitely against the same chain root).

**Delivery owner:** rico@hardseal.ai

**Engagement reference:** Operator overwrites this line with the engagement folder path or invoice reference once the bundle is forwarded to a named prospect.

---

## What this delivery contains

The accompanying bundle is a Hardseal Edge evidence delivery — a cryptographically signed JSON evidence packet recording one AI-inference session on the device named in this note, plus the materials necessary for the recipient to verify the packet independently.

Operator checklist (what's present in this bundle):

- [x] `packet.json` — signed evidence packet for the `yolov8x_1M_MAXN_chain_rep3_20260501T030344Z` session.
- [x] `packet.md` — human-readable view of the same evidence.
- [x] `verify_standalone.py` — single-file vendored verifier (stdlib-only Python, no install required).
- [x] `../QUICKSTART.md` — verifier walkthrough and 8-check explanation (one directory up; included in zipped distribution).
- [x] This `EDGE_DELIVERY_NOTE.md`.

---

## How to verify the packet

From the unzipped bundle directory, on any machine with Python 3.8 or later:

```
python3 verify_standalone.py yolov8x_1M_MAXN_chain_rep3_20260501T030344Z/packet.json
```

The verifier runs the same 8-check sequence Hardseal Edge runs internally; full check-by-check explanation lives in `QUICKSTART.md`.

Expected output for a clean packet: 8 PASS lines and `result: PASS`. Exit code `0`.

The verifier:

- Uses the Python standard library only — no `pip install`, no virtual environment.
- Makes no network calls.
- Depends on no Hardseal-hosted service.
- Will produce the same answer in 5 years against the same packet.

For verification issues or environment troubleshooting, see Support below.

---

## What PASS means

A `result: PASS` from the verifier confirms that:

- All required header and section fields are present and well-formed.
- The packet's recorded `schema_version` (`1.0`) and `operational_class` (`edge-inference-verification`) are recognized by the verifier.
- The cryptographic anchor (engine SHA-256 `0bca76afb2812c78b3bec68247146f0cbaf0156a2d7db0eb0cf257d39588ad1c`) is present in the model section.
- The SHA-256 hash chain over the packet's contents recomputes to the stored chain root `de870b4e3275fed1ee4bf07cbd7d8c824fe99200e2d566e5ede573c2debba138` — i.e., **no field of the packet has been modified since signing**.
- The packet contains no language asserting claims Hardseal Edge is doctrinally not permitted to make.

In plain terms: PASS confirms the named device executed the named TensorRT engine under the named configuration, produced the recorded measurements across 500,000 iterations of inference, and the entire record is sealed against tampering.

---

## What PASS does NOT mean

A `result: PASS` from the verifier does **not** confirm any of the following. These determinations are out of scope of a Hardseal Edge packet and require separate qualified judgment:

- The recipient's organization is compliant with CMMC, NIST 800-171, FedRAMP, DO-178, ISO 27001, SOC 2, or any other regulatory or contractual standard.
- Any specific compliance control is satisfied by the recorded evidence on its own.
- An assessor, registered provider organization, C3PAO, government agency, prime contractor, or regulator has approved, certified, endorsed, or authorized the recorded evidence or the system that produced it.
- The underlying AI model is safe, accurate, fit for any operational purpose, or approved for any specific use case.
- The deployment environment surrounding the recorded session is secure as a whole.
- The recorded measurements generalize to other devices, other thermal envelopes, other input distributions, other model precisions, or other workload types without separate measurement.

The cryptographic claim is narrow on purpose. The narrowness is what makes the evidence verifiable.

---

## Relevance disclaimer (verbatim — required language)

The following disclaimer language is part of every Hardseal Edge delivery and is reproduced verbatim from the Hardseal Edge collector specification:

> This evidence is relevant to the listed control families but does not, on its own, satisfy any specific control. Hardseal Edge attests only to the cryptographic integrity of the recorded session. Assessment of control satisfaction requires the customer's qualified assessor.

Control families this delivery may be relevant to:

- Operator overwrites this line at engagement time with the customer-specific control family mapping during scoping. This packet is methodology evidence; mapping inference telemetry to control satisfaction is the sole responsibility of the customer's qualified assessor.

The list above states *which control families this evidence may be relevant to*. It does **not** state that any control on the list is satisfied by this evidence alone. Mapping inference telemetry to control satisfaction is the sole responsibility of the customer's qualified assessor.

---

## Packet metadata reference

For the recipient's records and verification cross-check:

- **Operational class:** edge-inference-verification
- **Schema version:** 1.0
- **Hash-chain algorithm:** sha256_chain_v1
- **Verification command:** `python3 verify_standalone.py yolov8x_1M_MAXN_chain_rep3_20260501T030344Z/packet.json`
- **Expected exit codes:** `0` = PASS, `1` = FAIL, `2` = usage / unreadable file

| Packet (filename) | Chain root (first 32 hex) | Verifier result on delivery date |
|---|---|---|
| `yolov8x_1M_MAXN_chain_rep3_20260501T030344Z/packet.json` | `de870b4e3275fed1ee4bf07cbd7d8c82...` | PASS |

Full chain root (for a recipient who wants to record it byte-for-byte): `de870b4e3275fed1ee4bf07cbd7d8c824fe99200e2d566e5ede573c2debba138`

---

## Methodology summary (one-glance)

| Field | Value |
|---|---|
| Device | jetson_orin_nano_super |
| OS / kernel | ubuntu / R36.4.7 |
| JetPack | 6.2.1 |
| Power mode | MAXN_SUPER |
| Engine | `/home/rico/yolov8x_int8.engine` (tensorrt 10.3.0, int8 precision) |
| Engine SHA-256 | `0bca76afb2812c78b3bec68247146f0cbaf0156a2d7db0eb0cf257d39588ad1c` |
| Iterations | 500,000 |
| Warm-up iterations | 50 |
| Wall time | 9875.14 s (~164 min 35 s) |
| Mean latency | 19.737 ms |
| Median (p50) | 19.189 ms |
| p95 latency | 23.771 ms |
| p99 latency | 32.367 ms |
| Max latency | 38.689 ms |
| Throughput | 50.63 FPS |
| Thermal pre-soak | ~47.3 °C |
| Thermal post-soak | ~63.8 °C |
| Input data | Synthetic (np.random) — explicit packet limitation, no real sensor input |
| Sensors connected | None (camera, IMU, GPS, barometer all `not_connected` per packet) |
| Offline mode | true (no network calls during inference) |

The point of this session: produce a cryptographically sealed, independently verifiable record of one AI-inference workload on the named hardware under the named configuration.

---

## Note on tail behavior

The recorded p99 latency in this packet (~32.3 ms) is approximately 1.64x the mean latency (~19.7 ms). This ratio is consistent across all three reps in the replicate chain (1.639x, 1.642x, 1.640x — a 0.18% spread). This is a property of high-FPS edge inference under sustained MAXN_SUPER load on the Jetson Orin Nano Super: OS scheduler contention with system services, occasional memory-bandwidth pressure, and sub-throttle GPU clock micro-oscillations all contribute to a long tail. The packet preserves every measurement; recipients can examine the iteration array directly to see the distribution.

Operators using this evidence to characterize their own deployments should treat the p99/mean ratio as a property of the workload class, not a contamination artifact. For deployments where tail latency is a hard requirement (autonomy, time-critical safety functions), measure your own workload under your own thermal envelope rather than relying on this packet's distribution as a generalization.

---

## Support

Questions about interpreting these artifacts, verification environment troubleshooting, or integrating Hardseal Edge evidence into the recipient's compliance evidence package:

- **Email:** rico@hardseal.ai
- **Response window:** 4 business hours during the engagement window; 1 business day post-acceptance.
- **Out-of-scope questions** (legal interpretation, regulatory determination, assessment opinion) are explicitly NOT supported by Hardseal — those route to the recipient's qualified assessor or counsel.

---

## Internal delivery checklist (operator-only — strip before sending to a named recipient)

Before sealing the bundle and sending it, confirm:

- [ ] Packet verifies PASS via `python3 verify_standalone.py` (run before any forwarding).
- [ ] **Customer name field** is filled in for the named recipient.
- [ ] **Engagement reference** field is filled in with the engagement folder path or invoice reference.
- [x] Packet metadata table is filled in (chain root, verifier result, methodology summary).
- [x] The relevance disclaimer is present verbatim — not paraphrased, not edited, not abbreviated.
- [x] The "What PASS does NOT mean" section is intact — not edited to soften, not removed.
- [ ] **This internal-checklist section** is removed or struck through from the recipient-facing copy.

---

**Filed:** 2026-05-01T12:43:29Z. Hardseal Edge — auto-generated by post_rep_pipeline.sh.

*Operator review required before forwarding to a named recipient. Verbatim disclaimer sections must not be edited.*
