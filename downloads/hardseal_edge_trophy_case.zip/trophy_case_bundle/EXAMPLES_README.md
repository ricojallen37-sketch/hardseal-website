# Hardseal Edge — Sample-packet walkthrough

This file is a step-by-step walkthrough of running `verify_standalone.py` against the **T1 sample packet** in this bundle, plus a tampering demonstration that proves the integrity gate works.

The T1 packet is the recommended starting point for any first-time reviewer. Once you have run it once, the same command pattern works against any of the 7 other packets in this bundle (see `CHAIN_ROOT_MANIFEST.md` for the full list).

## What's in this folder

This file (`EXAMPLES_README.md`) lives at the top of the unzipped `trophy_case_bundle/`. The relevant files for this walkthrough are:

| File / directory | What it is |
|---|---|
| `verify_standalone.py` | Single-file standalone verifier. Stdlib-only Python. No `pip install`. |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` | Sample evidence packet — 1,000,000-iteration sustained inference soak. |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.md` | Human-readable Markdown view of the same packet. |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/EDGE_DELIVERY_NOTE.md` | Per-packet delivery note: scope, methodology, support contact. |
| `QUICKSTART.md` | Top-level verifier walkthrough and 8-check explanation. |
| `README.md` | Top-level bundle overview. |

## Run the example

From the unzipped `trophy_case_bundle/` directory:

```
python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json
```

Expected output: 8 PASS lines and `result: PASS`. Exit code 0.

```
  PASS: header fields complete
  PASS: schema_version supported
  PASS: operational_class recognized
  PASS: required sections present
  PASS: engine SHA-256 present
  PASS: offline mode declared
  PASS: hash chain valid
  PASS: no banned legal language detected

result: PASS
```

## What this proves

- The T1 packet has not been modified since signing.
- The named device (Jetson Orin Nano Super) executed the named engine (yolov8n INT8) under the named configuration (25 W, pinned clocks).
- The recorded measurements (3.405 ms mean / 293.07 FPS / 1,000,000 iterations / +3 to +5 °C thermal rise across 57 minutes) are sealed against tampering.

## What this does NOT claim

The cryptographic claim is narrow on purpose. See `QUICKSTART.md` (in this same directory) for the full scope, including the explicit list of regulatory regimes the verifier does NOT certify against.

## How to demonstrate the failure mode (tampering test)

1. Open `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` in a text editor.
2. Change any single value — for example, change the `mean_ms` from `3.4050` to `3.4051`.
3. Save the file.
4. Re-run `python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json`.
5. Watch the verifier identify the first mutated section by name and return `result: FAIL`.
6. Restore the original value to see PASS again.

The verifier's behavior under tampering is the most persuasive demonstration that the success case was real.

## Re-implementing the verifier

`verify_standalone.py` is intentionally readable (~250 lines, stdlib-only). The hash-chain construction is the load-bearing primitive. Re-implementing it in Rust, Go, C++, or any other language is encouraged — the same packet inputs should produce the same chain root in any compliant implementation.

## Provenance of this bundle

The 8 packets in this bundle were produced from real measurement runs on a Jetson Orin Nano Super between 2026-04-26 and 2026-04-29:

- 1 thermal-saturation soak (yolov8n INT8 @ 25 W, 1M iter)
- 1 sustained run (yolov8L INT8 @ 25 W, 1M iter)
- 6 replicate-chain packets across two independent 3-rep MAXN_SUPER chains (yolov8L INT8, 1M iter each)

Each packet's `EDGE_DELIVERY_NOTE.md` contains the per-run methodology summary and chain-of-custody for that specific measurement. The `CHAIN_ROOT_MANIFEST.md` at the top of the bundle lists the full SHA-256 chain root of every packet for out-of-band verification.
