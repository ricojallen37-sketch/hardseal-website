# Hardseal Edge — Examples

This folder contains a complete, runnable Hardseal Edge sample.

## What's in here

| File / directory | What it is |
|---|---|
| `verify_standalone.py` | Single-file standalone verifier. Stdlib-only Python. No `pip install`. |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` | Sample evidence packet — 1,000,000-iteration sustained inference soak. |
| `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.md` | Human-readable Markdown view of the same packet. |
| `README.md` | This file. |

## Run the example

From this folder, run:

```
python3 verify_standalone.py T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json
```

Expected output: 8 PASS lines and `result: PASS`. Exit code 0.

```
  PASS: header fields complete
  PASS: schema_version supported
  PASS: operational_class recognized
  PASS: required sections present
  PASS: engine SHA-256 present
  PASS: offline mode declared
  PASS: hash chain valid
  PASS: no banned legal language detected

result: PASS
```

## What this proves

- The packet has not been modified since signing.
- The named device (Jetson Orin Nano Super) executed the named engine (yolov8n INT8) under the named configuration (25 W, pinned clocks).
- The recorded measurements (3.405 ms mean / 293.07 FPS / 1,000,000 iterations / +3 to +5 °C thermal rise across 57 minutes) are sealed against tampering.

## What this does NOT claim

The cryptographic claim is narrow on purpose. See `../QUICKSTART.md` for the full scope.

## How to verify it tampered

1. Open `T1_thermal_saturation_yolov8n_int8_25W_1M_iter/packet.json` in a text editor.
2. Change any single value — for example, change the `mean_ms` from `3.4050` to `3.4051`.
3. Save the file.
4. Re-run `python3 verify_standalone.py ...`.
5. Watch the verifier identify the first mutated section by name and return `result: FAIL`.
6. Restore the original value to see PASS again.

The verifier's behavior under tampering is the most persuasive demonstration that the success case was real.

## Re-implementing the verifier

`verify_standalone.py` is intentionally readable (~250 lines, stdlib-only). The hash-chain construction is the load-bearing primitive. Re-implementing it in Rust, Go, C++, or any other language is encouraged — the same packet inputs should produce the same chain root in any compliant implementation.

## Provenance

The sample packet was produced from a real overnight measurement run (`overnight_full_matrix_20260426T012800Z`) on 2026-04-26. It is one of 22 packets sealed during that run; the others span the full deployment matrix (15 W / 25 W / MAXN_SUPER × yolov8 n/s/m × FP16/INT8) with replicates and a thermal saturation soak.
