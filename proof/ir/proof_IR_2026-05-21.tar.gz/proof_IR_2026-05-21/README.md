# Hardseal Public Proof — IR Family (Incident Response)

**Single-family reference proof.** This pack contains a complete,
offline-verifiable Hardseal Core readiness extract for **one CMMC L2
control family** — NIST 800-171 §3.6 (Incident Response, controls
3.6.1 / 3.6.2 / 3.6.3) — from a synthetic Acme Precision Components,
Inc. reference build dated 2026-05-21.

It is published so that a stranger can download it, run a stdlib-only
Python verifier, and confirm offline that nothing in the pack has been
altered.

## What's inside

- `README.md` — this file
- `summary-report.txt` — one-page summary + cross-checked counts
- `assessment/SSP.json` — the 3 IR SSP narratives (all-real evidence citations, no placeholders)
- `assessment/POAM.csv` — IR-family Plan of Action & Milestones rows
- `assessment/assessment-results.json` — IR-family OSCAL findings + observations (1.1.2)
- `evidence/INDEX.csv` — IR-family evidence index (6 rows)
- `evidence/INDEX.md` — human-readable IR evidence index
- `evidence/evidence-bundle.json` — re-chained Layer-2 evidence bundle (6 artifacts, chain_head `ba3ab83e939438b3…`)
- `evidence/evidence-bundle.json.sig` — placeholder; HMAC secret not shipped (see HOW_TO_VERIFY.md)
- `manifest.sha256` — SHA-256 of every content file in this pack
- `manifest.sha256.sig` — HMAC-SHA256 detached signature of the manifest (ephemeral secret, not shipped)
- `verify/HOW_TO_VERIFY.md` — offline verification + tamper-demo walkthrough
- `verify/verify_standalone.py` — single-file Python verifier (the entire trust surface)

## How to verify (30 seconds)

```bash
python3 verify/verify_standalone.py .
```

Expected:

```
[*] Verifying manifest checksums... OK (<N>/<N> files)
[*] Verifying hash chain... OK (6 links)
[*] No integrity tag present on bundle.
[+] VERIFICATION PASSED -- bundle integrity confirmed.
```

Exit code `0`. Anything else means the pack has been altered.

## Tamper demo

```bash
echo "x" >> evidence/INDEX.csv
python3 verify/verify_standalone.py .
```

Expected: exit `1`, named-file SHA-256 mismatch.

## What this proof DOES and DOES NOT claim

**Proves cryptographically, offline:** every artifact_hash in
`evidence-bundle.json` is a real SHA-256 of collected content; the
Layer-2 hash chain over 6 IR artifacts is intact; the package-level
manifest is intact.

**Does NOT claim:** production-grade readiness against the full 110
CMMC L2 controls; compliance certification, assessment, or
RPO/C3PAO endorsement; that the Acme Precision Components, Inc.
profile is a real customer (it is a structurally-realistic
reference profile).

Hardseal is a pre-assessment readiness product. Hardseal does not
certify, assess, or endorse anything.
