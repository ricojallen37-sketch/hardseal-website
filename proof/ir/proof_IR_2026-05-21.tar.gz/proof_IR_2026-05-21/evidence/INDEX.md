# Evidence Index — IR Family (Incident Response)

**Single-family reference proof.** This index lists the evidence
artifacts associated with NIST 800-171 §3.6 (Incident Response) for
the Acme Precision Components, Inc. reference build dated 2026-05-21.

Every `artifact_hash` is a real SHA-256 of collected content. Run
`python3 verify/verify_standalone.py .` from the unpacked pack root
to confirm the chain + manifest verify cleanly. See
`verify/HOW_TO_VERIFY.md` for the offline tamper demo.

## Controls

### 3.6.1 — Incident Handling

- `a21ec37c` · policy_document · No policy document found for IR-2 -- policies directory does not exist: /Users/rico/Documents/Claude · `sha256:5fc3321c023446dd…`
- `b675f4ae` · policy_document · No policy document found for 3.6.1 -- policies directory does not exist: /Users/rico/Documents/Claud · `sha256:c538e4e0fc461a91…`

### 3.6.2 — Incident Tracking and Reporting

- `1f99e980` · policy_document · No policy document found for 3.6.2 -- policies directory does not exist: /Users/rico/Documents/Claud · `sha256:1cce9beacb8415d5…`
- `58595e1f` · policy_document · No policy document found for IR-4 -- policies directory does not exist: /Users/rico/Documents/Claude · `sha256:9d608cca35e75f06…`

### 3.6.3 — Incident Response Testing

- `6870c731` · policy_document · No policy document found for 3.6.3 -- policies directory does not exist: /Users/rico/Documents/Claud · `sha256:6fbaaa6fe53f7eba…`
- `e5c6b8a5` · policy_document · No policy document found for IR-6 -- policies directory does not exist: /Users/rico/Documents/Claude · `sha256:283d0ba70d533260…`
